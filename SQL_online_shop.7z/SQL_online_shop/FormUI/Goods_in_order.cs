﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormUI
{
    public class Goods_in_order
    {
        public int id_good { get; set; }
        public int id_ourder { get; set; }
        public int Quantity { get; set; }
    }
}
