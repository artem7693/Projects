﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{
    public partial class Select : Form
    {
        public Select()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Всё о покупателях")
            {
                this.Hide();
                Otnoshenie form = new Otnoshenie();
                form.ShowDialog();
            }
            if (comboBox1.Text == "Всё о продавцах")
            {
                this.Hide();
                Otnoshenie2 form = new Otnoshenie2();
                form.ShowDialog();
            }
            if (comboBox1.Text == "Всё о товарах")
            {
                this.Hide();
                Otnoshenie3 form = new Otnoshenie3();
                form.ShowDialog();
            }
        }

        private void Select_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
