﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using System.Data;
using System.Data.OleDb;

namespace FormUI
{
    public class DataAccess
    {
        private OleDbConnection myConnection;
        public List<Buyer> GetBuyers(string fIO)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Online_shop_DB")))
            {
                var output = connection.Query<Buyer>($"select * from Buyer where FIO = '{ fIO }'").ToList();
                return output;
            }
        }

        public List<Seller> GetSellers(string fIO)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Online_shop_DB")))
            {
                var output = connection.Query<Seller>($"select * from Seller where FIO = '{ fIO }'").ToList();
                return output;
            }
        }

        public void InsertBuyer(string fio, string address, string city, string phone_number)
        {
            //using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Online_shop_DB")))
            //{
            //    Buyer newBuyer = new Buyer { FIO = fio, Address = address, City = city, Phone_number = phone_number };
            //    List<Buyer> Buyers = new List<Buyer>();
            //    Buyers.Add(new Buyer { FIO = fio, Address = address, City = city, Phone_number = phone_number });

            //    connection.Execute("Buyer @FIO, @Address, @City, @Phone_number", Buyers);
            //}
            //string query = "INSERT INTO Buyer (fio, address, city, phone_number) VALUES (@fio, @address, @city, @phone_number)";
            //OleDbCommand command = new OleDbCommand(query, myConnection);
            //command.ExecuteNonQuery();
        }

        //internal List<Good> GetQuantity(string Quantity)
        //{
        //    using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("Online_shop_DB")))
        //    {
        //        return connection.Query<Good>($"SELECT club_Profit * (2019 - { Year } + 1) as profit From Good where Club_ID = (SELECT ID FROM Clubs where name = '{ clubName }' )").ToList();
        //    }
        //}
    }
}