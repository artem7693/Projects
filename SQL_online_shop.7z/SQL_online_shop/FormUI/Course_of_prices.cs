﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormUI
{
    public class Course_of_prices
    {
        public int id_good { get; set; }
        public string Price { get; set; }
        public DateTime Date { get; set; }
    }
}
