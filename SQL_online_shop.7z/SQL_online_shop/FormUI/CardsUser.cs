﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace FormUI
{
    public partial class CardsUser : Form
    {
        List<Card> Card = new List<Card>();

        SqlCommand cmd;

        public CardsUser()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True");

        private void button2_Click(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True");
            con.Open();
            cmd = new SqlCommand("INSERT INTO Card_View(id_buyer, number, term, code) VALUES (@id_buyer, @number, @term, @code)", con);
            cmd.Parameters.Add("@id_buyer", textBox3.Text);
            cmd.Parameters.Add("@number", textBox4.Text);
            cmd.Parameters.Add("@term", textBox5.Text);
            cmd.Parameters.Add("@code", textBox6.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Данные введены");
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
        }

        private void CardsUser_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            con.Close();
            try
            {
                if (textBox3.Text == "")
                {
                    MessageBox.Show("Введите ID для обновления");
                }
                else
                {
                    con.Open();
                    SqlCommand cmdupdate = new SqlCommand("Update Card SET id_buyer='" + textBox3.Text + "',Number='" + textBox4.Text + "' ,Term='" + textBox5.Text + "' ,Code='" + textBox6.Text + "' where id_buyer=" + textBox3.Text + "", con);
                    cmdupdate.CommandType = CommandType.Text;
                    cmdupdate.ExecuteNonQuery();
                    MessageBox.Show("База обновлена");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            User form = new User();
            form.ShowDialog();
        }
    }
}
