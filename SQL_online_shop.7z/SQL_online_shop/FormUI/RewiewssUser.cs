﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace FormUI
{
    public partial class RewiewssUser : Form
    {
        List<Rewiews> Rewiews = new List<Rewiews>();

        SqlCommand cmd;

        public RewiewssUser()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True");

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd = new SqlCommand("INSERT INTO Rewiews_View_View(id_good, id_buyer, id_seller, rate, note, date) VALUES (@id_good, @id_buyer, @id_seller, @rate, @note, @date)", con);
            cmd.Parameters.Add("@id_good", textBox2.Text);
            cmd.Parameters.Add("@id_buyer", textBox3.Text);
            cmd.Parameters.Add("@id_seller", textBox4.Text);
            cmd.Parameters.Add("@rate", textBox5.Text);
            cmd.Parameters.Add("@note", textBox6.Text);
            cmd.Parameters.Add("@date", textBox7.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Данные введены");
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
        }

        private void RewiewssUser_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            User form = new User();
            form.ShowDialog();
        }
    }
}
