﻿//using System;
//using System.Collections.Generic;
//using System.Configuration;
//using System.Data.SqlClient;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Windows.Forms;

//namespace FormUI
//{
//    class Logininsystem2
//    {
//        static string myconnstrng = ConfigurationManager.ConnectionStrings["connstrng"].ConnectionString;

//        public bool loginCheck(Logininsystem l)
//        {
//            bool isSuccess = false;
//            SqlConnection conn = new SqlConnection(myconnstrng);

//            try
//            {


//            }
//            catch (Exception ex)
//            {

//                MessageBox.Show(ex.Message);
//            }
//            finally
//            {
//                conn.Close();
//            }

//            return isSuccess;

//        }
//    }
//}
