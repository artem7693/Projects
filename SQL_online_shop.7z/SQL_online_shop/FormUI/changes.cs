﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace FormUI
{
    public partial class changes : Form
    {
        List<Delivery> Delivery = new List<Delivery>();

        SqlCommand cmd;
        SqlConnection con;
        public changes()
        {
            InitializeComponent();
        }

        private void changes_Load(object sender, EventArgs e)
        {

        }

        private void changes_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
            SqlConnection myConnection = new SqlConnection(connectString);
            myConnection.Open();
            //string cmbItemValue = comboBox1.SelectedItem.ToString();
            if (comboBox1.Text == "Продавцы")
            {
                string query = "SELECT id_buyer, Date_of_sending FROM Delivery";
                SqlCommand command = new SqlCommand(query, myConnection);
                SqlDataReader reader = command.ExecuteReader();
                List<string[]> data = new List<string[]>();
                while (reader.Read())
                {
                    data.Add(new string[2]);
                    data[data.Count - 1][0] = reader[0].ToString();
                    data[data.Count - 1][1] = reader[1].ToString();
                }
                reader.Close();
                myConnection.Close();
                foreach (string[] s in data)
                    dataGridView1.Rows.Add(s);
            }
            if (comboBox1.Text == "Покупатели")
            {
                MessageBox.Show("Ошибка");
            }
        }
    }
}
