﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace FormUI
{
    public partial class Admin : Form
    {
        List<Buyer> Buyer = new List<Buyer>();

        SqlCommand cmd;
        SqlConnection con;
        public Admin()
        {
            InitializeComponent();
        }

        private void Admin_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Покупатели")
            {
                string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
                SqlConnection myConnection = new SqlConnection(connectString);
                myConnection.Open();
                string query = "SELECT ID, FIO, Address, City FROM Buyer";
                SqlCommand command = new SqlCommand(query, myConnection);
                SqlDataReader reader = command.ExecuteReader();
                List<string[]> data = new List<string[]>();
                while (reader.Read())
                {
                    data.Add(new string[4]);
                    data[data.Count - 1][0] = reader[0].ToString();
                    data[data.Count - 1][1] = reader[1].ToString();
                    data[data.Count - 1][2] = reader[2].ToString();
                    data[data.Count - 1][3] = reader[3].ToString();
                }
                reader.Close();
                myConnection.Close();
                foreach (string[] s in data)
                    dataGridView1.Rows.Add(s);
            }
            if (comboBox1.Text == "Продавцы")
            {
                string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
                SqlConnection myConnection = new SqlConnection(connectString);
                myConnection.Open();
                string query = "SELECT ID, FIO, Address, Rating FROM Seller";
                SqlCommand command = new SqlCommand(query, myConnection);
                SqlDataReader reader = command.ExecuteReader();
                List<string[]> data = new List<string[]>();
                while (reader.Read())
                {
                    data.Add(new string[4]);
                    data[data.Count - 1][0] = reader[0].ToString();
                    data[data.Count - 1][1] = reader[1].ToString();
                    data[data.Count - 1][2] = reader[2].ToString();
                    data[data.Count - 1][3] = reader[3].ToString();
                }
                reader.Close();
                myConnection.Close();
                foreach (string[] s in data)
                    dataGridView2.Rows.Add(s);
            }
            if (comboBox1.Text == "Заказы")
            {
                string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
                SqlConnection myConnection = new SqlConnection(connectString);
                myConnection.Open();
                string query = "SELECT ID, id_buyer, id_seller, Data_and_time, Sale FROM Ourder";
                SqlCommand command = new SqlCommand(query, myConnection);
                SqlDataReader reader = command.ExecuteReader();
                List<string[]> data = new List<string[]>();
                while (reader.Read())
                {
                    data.Add(new string[5]);
                    data[data.Count - 1][0] = reader[0].ToString();
                    data[data.Count - 1][1] = reader[1].ToString();
                    data[data.Count - 1][2] = reader[2].ToString();
                    data[data.Count - 1][3] = reader[3].ToString();
                    data[data.Count - 1][4] = reader[4].ToString();
                }
                reader.Close();
                myConnection.Close();
                foreach (string[] s in data)
                    dataGridView3.Rows.Add(s);
            }
            if (comboBox1.Text == "Производители")
            {
                string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
                SqlConnection myConnection = new SqlConnection(connectString);
                myConnection.Open();
                string query = "SELECT ID, Country, Name, Address, Email FROM Manufacturer";
                SqlCommand command = new SqlCommand(query, myConnection);
                SqlDataReader reader = command.ExecuteReader();
                List<string[]> data = new List<string[]>();
                while (reader.Read())
                {
                    data.Add(new string[5]);
                    data[data.Count - 1][0] = reader[0].ToString();
                    data[data.Count - 1][1] = reader[1].ToString();
                    data[data.Count - 1][2] = reader[2].ToString();
                    data[data.Count - 1][3] = reader[3].ToString();
                    data[data.Count - 1][4] = reader[4].ToString();
                }
                reader.Close();
                myConnection.Close();
                foreach (string[] s in data)
                    dataGridView4.Rows.Add(s);
            }
            if (comboBox1.Text == "Товары")
            {
                string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
                SqlConnection myConnection = new SqlConnection(connectString);
                myConnection.Open();
                string query = "SELECT ID, id_manufacturer, Quantity, Price, id_type_of_good FROM Good";
                SqlCommand command = new SqlCommand(query, myConnection);
                SqlDataReader reader = command.ExecuteReader();
                List<string[]> data = new List<string[]>();
                while (reader.Read())
                {
                    data.Add(new string[5]);
                    data[data.Count - 1][0] = reader[0].ToString();
                    data[data.Count - 1][1] = reader[1].ToString();
                    data[data.Count - 1][2] = reader[2].ToString();
                    data[data.Count - 1][3] = reader[3].ToString();
                    data[data.Count - 1][4] = reader[4].ToString();
                }
                reader.Close();
                myConnection.Close();
                foreach (string[] s in data)
                    dataGridView5.Rows.Add(s);
            }
            if (comboBox1.Text == "Карты")
            {
                string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
                SqlConnection myConnection = new SqlConnection(connectString);
                myConnection.Open();
                string query = "SELECT ID, id_buyer, Number, Term, Code FROM Card";
                SqlCommand command = new SqlCommand(query, myConnection);
                SqlDataReader reader = command.ExecuteReader();
                List<string[]> data = new List<string[]>();
                while (reader.Read())
                {
                    data.Add(new string[5]);
                    data[data.Count - 1][0] = reader[0].ToString();
                    data[data.Count - 1][1] = reader[1].ToString();
                    data[data.Count - 1][2] = reader[2].ToString();
                    data[data.Count - 1][3] = reader[3].ToString();
                    data[data.Count - 1][4] = reader[4].ToString();
                }
                reader.Close();
                myConnection.Close();
                foreach (string[] s in data)
                    dataGridView6.Rows.Add(s);
            }
            if (comboBox1.Text == "Офисы")
            {
                string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
                SqlConnection myConnection = new SqlConnection(connectString);
                myConnection.Open();
                string query = "SELECT ID, City, Address, Name, Indecs FROM Office";
                SqlCommand command = new SqlCommand(query, myConnection);
                SqlDataReader reader = command.ExecuteReader();
                List<string[]> data = new List<string[]>();
                while (reader.Read())
                {
                    data.Add(new string[5]);
                    data[data.Count - 1][0] = reader[0].ToString();
                    data[data.Count - 1][1] = reader[1].ToString();
                    data[data.Count - 1][2] = reader[2].ToString();
                    data[data.Count - 1][3] = reader[3].ToString();
                    data[data.Count - 1][4] = reader[4].ToString();
                }
                reader.Close();
                myConnection.Close();
                foreach (string[] s in data)
                    dataGridView7.Rows.Add(s);
            }
            if (comboBox1.Text == "Доставки")
            {
                string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
                SqlConnection myConnection = new SqlConnection(connectString);
                myConnection.Open();
                string query = "SELECT ID, id_seller, id_buyer, id_office, id_ourder, Track_number, Date_of_sending FROM Delivery";
                SqlCommand command = new SqlCommand(query, myConnection);
                SqlDataReader reader = command.ExecuteReader();
                List<string[]> data = new List<string[]>();
                while (reader.Read())
                {
                    data.Add(new string[7]);
                    data[data.Count - 1][0] = reader[0].ToString();
                    data[data.Count - 1][1] = reader[1].ToString();
                    data[data.Count - 1][2] = reader[2].ToString();
                    data[data.Count - 1][3] = reader[3].ToString();
                    data[data.Count - 1][4] = reader[4].ToString();
                    data[data.Count - 1][5] = reader[5].ToString();
                    data[data.Count - 1][6] = reader[6].ToString();
                }
                reader.Close();
                myConnection.Close();
                foreach (string[] s in data)
                    dataGridView8.Rows.Add(s);
            }
            if (comboBox1.Text == "Курсы цен")
            {
                string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
                SqlConnection myConnection = new SqlConnection(connectString);
                myConnection.Open();
                string query = "SELECT id_good, Price, Date FROM Course_of_prices";
                SqlCommand command = new SqlCommand(query, myConnection);
                SqlDataReader reader = command.ExecuteReader();
                List<string[]> data = new List<string[]>();
                while (reader.Read())
                {
                    data.Add(new string[3]);
                    data[data.Count - 1][0] = reader[0].ToString();
                    data[data.Count - 1][1] = reader[1].ToString();
                    data[data.Count - 1][2] = reader[2].ToString();
                }
                reader.Close();
                myConnection.Close();
                foreach (string[] s in data)
                    dataGridView9.Rows.Add(s);
            }
            if (comboBox1.Text == "Товары в заказе")
            {
                string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
                SqlConnection myConnection = new SqlConnection(connectString);
                myConnection.Open();
                string query = "SELECT id_good, id_ourder, Quantity FROM Goods_in_order";
                SqlCommand command = new SqlCommand(query, myConnection);
                SqlDataReader reader = command.ExecuteReader();
                List<string[]> data = new List<string[]>();
                while (reader.Read())
                {
                    data.Add(new string[3]);
                    data[data.Count - 1][0] = reader[0].ToString();
                    data[data.Count - 1][1] = reader[1].ToString();
                    data[data.Count - 1][2] = reader[2].ToString();
                }
                reader.Close();
                myConnection.Close();
                foreach (string[] s in data)
                    dataGridView10.Rows.Add(s);
            }
            if (comboBox1.Text == "Отзывы")
            {
                string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
                SqlConnection myConnection = new SqlConnection(connectString);
                myConnection.Open();
                string query = "SELECT id_good, id_buyer, id_seller, Rate, Note, Date FROM Rewiews";
                SqlCommand command = new SqlCommand(query, myConnection);
                SqlDataReader reader = command.ExecuteReader();
                List<string[]> data = new List<string[]>();
                while (reader.Read())
                {
                    data.Add(new string[6]);
                    data[data.Count - 1][0] = reader[0].ToString();
                    data[data.Count - 1][1] = reader[1].ToString();
                    data[data.Count - 1][2] = reader[2].ToString();
                    data[data.Count - 1][3] = reader[3].ToString();
                    data[data.Count - 1][4] = reader[4].ToString();
                    data[data.Count - 1][5] = reader[5].ToString();
                }
                reader.Close();
                myConnection.Close();
                foreach (string[] s in data)
                    dataGridView11.Rows.Add(s);
            }

            //private void UpdateBinding()
            //{
            //    listBox1.DataSource = Buyer;
            //    listBox1.DisplayMember = "FullInfo";
            //}

            //private void label6_Click(object sender, EventArgs e)
            //{

            //}

            //private void button2_Click(object sender, EventArgs e)
            //{
            //    con = new SqlConnection(@"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True");
            //    con.Open();
            //    cmd = new SqlCommand("SET IDENTITY_INSERT Buyer ON INSERT INTO Buyer(id, fio, address, city, country, sale) VALUES (@id, @fio, @address, @city, @country, @sale)", con);
            //    cmd.Parameters.Add("@id", textBox2.Text);
            //    cmd.Parameters.Add("@fio", textBox3.Text);
            //    cmd.Parameters.Add("@address", textBox4.Text);
            //    cmd.Parameters.Add("@city", textBox5.Text);
            //    cmd.Parameters.Add("@country", textBox6.Text);
            //    cmd.Parameters.Add("@sale", textBox7.Text);
            //    cmd.ExecuteNonQuery();
            //    textBox2.Clear();
            //    textBox3.Clear();
            //    textBox4.Clear();
            //    textBox5.Clear();
            //    textBox6.Clear();
            //    textBox7.Clear();
            //}

            //private void button3_Click(object sender, EventArgs e)
            //{
            //    string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
            //    SqlConnection myConnection = new SqlConnection(connectString);
            //    myConnection.Open();
            //    string query = "SELECT ID, FIO, Address, City FROM Buyer";
            //    SqlCommand command = new SqlCommand(query, myConnection);
            //    SqlDataReader reader = command.ExecuteReader();
            //    List<string[]> data = new List<string[]>();
            //    while (reader.Read())
            //    {
            //        data.Add(new string[4]);
            //        data[data.Count - 1][0] = reader[0].ToString();
            //        data[data.Count - 1][1] = reader[1].ToString();
            //        data[data.Count - 1][2] = reader[2].ToString();
            //        data[data.Count - 1][3] = reader[3].ToString();
            //    }
            //    reader.Close();
            //    myConnection.Close();
            //    foreach (string[] s in data)
            //        dataGridView1.Rows.Add(s);
            //}

            //private void button1_Click(object sender, EventArgs e)
            //{
            //    DataAccess db = new DataAccess();
            //    Buyer = db.GetBuyers(textBox1.Text);
            //    UpdateBinding();
            //}

            //private void Admin_FormClosed(object sender, FormClosedEventArgs e)
            //{
            //    Application.Exit();
            //}

            //private void button4_Click(object sender, EventArgs e)
            //{
            //    this.Hide();
            //    Buyers form = new Buyers();
            //    form.ShowDialog();
            //}


        }

        private void Admin_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Покупатели")
            {
                this.Hide();
                Buyers form = new Buyers();
                form.ShowDialog();
            }
            if (comboBox1.Text == "Продавцы")
            {
                this.Hide();
                Sellers form = new Sellers();
                form.ShowDialog();
            }
            if (comboBox1.Text == "Заказы")
            {
                this.Hide();
                Ourders form = new Ourders();
                form.ShowDialog();
            }
            if (comboBox1.Text == "Производители")
            {
                this.Hide();
                Manufacturers form = new Manufacturers();
                form.ShowDialog();
            }
            if(comboBox1.Text == "Товары")
            {
                this.Hide();
                Goods form = new Goods();
                form.ShowDialog();
            }
            if (comboBox1.Text == "Карты")
            {
                this.Hide();
                Cards form = new Cards();
                form.ShowDialog();
            }
            if (comboBox1.Text == "Офисы")
            {
                this.Hide();
                Offices form = new Offices();
                form.ShowDialog();
            }
            if (comboBox1.Text == "Доставки")
            {
                this.Hide();
                Deliverys form = new Deliverys();
                form.ShowDialog();
            }
            if (comboBox1.Text == "Курсы цен")
            {
                this.Hide();
                Course_of_pricess form = new Course_of_pricess();
                form.ShowDialog();
            }
            if (comboBox1.Text == "Товары в заказе")
            {
                this.Hide();
                Goods_in_orders form = new Goods_in_orders();
                form.ShowDialog();
            }
            if (comboBox1.Text == "Отзывы")
            {
                this.Hide();
                Rewiewss form = new Rewiewss();
                form.ShowDialog();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Select form = new Select();
            form.ShowDialog();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login form = new Login();
            form.ShowDialog();
        }
    }
}
