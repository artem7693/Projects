﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace FormUI
{
    public partial class Goods_in_ordersUser : Form
    {
        List<Goods_in_order> Goods_un_order = new List<Goods_in_order>();

        SqlCommand cmd;

        public Goods_in_ordersUser()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True");

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd = new SqlCommand("INSERT INTO Goods_in_order_View(id_good, id_ourder, quantity) VALUES (@id_good, @id_ourder, @quantity)", con);
            cmd.Parameters.Add("@id_good", textBox2.Text);
            cmd.Parameters.Add("@id_ourder", textBox3.Text);
            cmd.Parameters.Add("@quantity", textBox4.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Данные введены");
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
        }

        private void Goods_in_ordersUser_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            User form = new User();
            form.ShowDialog();
        }
    }
}
