﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

//namespace FormUI
//{
//    public partial class Form1 : Form
//    {
//        List<Buyer> Buyer = new List<Buyer>();
//        public Form1()
//        {
//            InitializeComponent();
//            UpdateBinding();
//        }

//        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
//        {

//        }

//        private void UpdateBinding()
//        {
//            listBox1.DataSource = Buyer;
//            listBox1.DisplayMember = "FullInfo";
//        }

//        private void button1_Click(object sender, EventArgs e)
//        {
//            DataAccess db = new DataAccess();
//            Buyer = db.GetBuyers(textBox1.Text);
//            UpdateBinding();
//        }

//        private void textBox4_TextChanged(object sender, EventArgs e)
//        {

//        }

//        private void button2_Click(object sender, EventArgs e)
//        {
//            DataAccess db = new DataAccess();
//            db.InsertBuyer(textBox2.Text, textBox3.Text, textBox4.Text, textBox5.Text);
//            textBox2.Text = "";
//            textBox3.Text = "";
//            textBox4.Text = "";
//            textBox5.Text = "";
//        }
//    }
//}


//namespace FormUI
//{
//    public partial class Form1 : Form
//    {
//        public static string connectString = "Provider=System.Data.SqlClient;Data Source=Online_shop;";
//        public OleDbConnection myConnection;

//        List<Buyer> Buyer = new List<Buyer>();
//        public Form1()
//        {
//            InitializeComponent();
//            myConnection = new OleDbConnection(connectString);

//            UpdateBinding();
//        }

//        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
//        {

//        }

//        private void UpdateBinding()
//        {
//            listBox1.DataSource = Buyer;
//            listBox1.DisplayMember = "FullInfo";
//        }

//        private void button1_Click(object sender, EventArgs e)
//        {
//            DataAccess db = new DataAccess();
//            Buyer = db.GetBuyers(textBox1.Text);
//            UpdateBinding();
//        }

//        private void textBox4_TextChanged(object sender, EventArgs e)
//        {

//        }

//        private void button2_Click(object sender, EventArgs e)
//        {
//            DataAccess db = new DataAccess();
//            db.InsertBuyer(textBox2.Text, textBox3.Text, textBox4.Text, textBox5.Text);
//            textBox2.Text = "";
//            textBox3.Text = "";
//            textBox4.Text = "";
//            textBox5.Text = "";
//        }

//        private void button3_Click(object sender, EventArgs e)
//        {
//            string query = "SELECT FIO FROM Buyer WHERE ID = 1";
//            OleDbCommand command = new OleDbCommand(query, myConnection);
//            textBox6.Text = command.ExecuteScalar().ToString();

//        }
//    }
//}


namespace FormUI
{
    public partial class Form1 : Form
    {
        List<Buyer> Buyer = new List<Buyer>();

        SqlCommand cmd;
        SqlConnection con;

        public Form1()
        {
            InitializeComponent();
            UpdateBinding();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void UpdateBinding()
        {
            listBox1.DataSource = Buyer;
            listBox1.DisplayMember = "FullInfo";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataAccess db = new DataAccess();
            Buyer = db.GetBuyers(textBox1.Text);
            UpdateBinding();

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=W12-416-04;Initial Catalog=Online_shop;Integrated Security=True");
            con.Open();
            cmd = new SqlCommand("INSERT INTO Buyer(fio, address, city, country) VALUES (@fio, @address, @city, @country)", con);
            cmd.Parameters.Add("@fio", textBox2.Text);
            cmd.Parameters.Add("@address", textBox3.Text);
            cmd.Parameters.Add("@city", textBox4.Text);
            cmd.Parameters.Add("@country", textBox5.Text);
            cmd.ExecuteNonQuery();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
        }

        //public string get_cs()
        //{
        //    return @"Data Source=АРТЁМ-ПК\\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
        //}

        private void button3_Click(object sender, EventArgs e)
        {
            //using (var connection = new SqlConnection(@"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True"))
            //{
            //    connection.Open();
            //    using (var cmd = new SqlCommand("SELECT FIO FROM Buyer WHERE Sale > 5", connection))
            //    {
            //        using (var rd = cmd.ExecuteReader())
            //        {
            //            if (rd.Read())
            //            {
            //                //listBox2.Items.Add(rd.GetValue(0).ToString());
            //                dataGridView1.Rows.Add(rd.GetValue(0).ToString());
            //            }
            //        }
            //    }
            //    connection.Close();
            //}

                string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
                SqlConnection myConnection = new SqlConnection(connectString);
                myConnection.Open();
                string query = "SELECT FIO FROM Buyer WHERE Sale > 5";
                SqlCommand command = new SqlCommand(query, myConnection);
                SqlDataReader reader = command.ExecuteReader();
                List<string[]> data = new List<string[]>();
                while(reader.Read())
                {
                    data.Add(new string[1]);
                    data[data.Count - 1][0] = reader[0].ToString();
                }
                reader.Close();
                myConnection.Close();
                foreach (string[] s in data)
                    dataGridView1.Rows.Add(s);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}