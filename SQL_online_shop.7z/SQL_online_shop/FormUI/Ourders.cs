﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace FormUI
{
    public partial class Ourders : Form
    {
        List<Ourder> Ourder = new List<Ourder>();

        SqlCommand cmd;

        public Ourders()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True");

        private void button1_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dataGridView1.RowCount; i++)
                if (dataGridView1[1, i].FormattedValue.ToString().
                    Contains(textBox1.Text.Trim()))
                {    
                    dataGridView1.CurrentCell = dataGridView1[0, i];
                    dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.Red;
                    return;
                }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True");
            con.Open();
            cmd = new SqlCommand("SET IDENTITY_INSERT Ourder ON INSERT INTO Ourder(id, id_buyer, id_seller, Data_and_time, sale) VALUES (@id, @id_buyer, @id_seller, @Data_and_time, @sale)", con);
            cmd.Parameters.Add("@id", textBox2.Text);
            cmd.Parameters.Add("@id_buyer", textBox3.Text);
            cmd.Parameters.Add("@id_seller", textBox4.Text);
            cmd.Parameters.Add("@Data_and_time", textBox5.Text);
            cmd.Parameters.Add("@sale", textBox6.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Данные введены");
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
            SqlConnection myConnection = new SqlConnection(connectString);
            myConnection.Open();
            string query = "SELECT ID, id_buyer, id_seller, Data_and_time, Sale FROM Ourder";
            SqlCommand command = new SqlCommand(query, myConnection);
            SqlDataReader reader = command.ExecuteReader();
            List<string[]> data = new List<string[]>();
            while (reader.Read())
            {
                data.Add(new string[5]);
                data[data.Count - 1][0] = reader[0].ToString();
                data[data.Count - 1][1] = reader[1].ToString();
                data[data.Count - 1][2] = reader[2].ToString();
                data[data.Count - 1][3] = reader[3].ToString();
                data[data.Count - 1][4] = reader[4].ToString();
            }
            reader.Close();
            myConnection.Close();
            foreach (string[] s in data)
                dataGridView1.Rows.Add(s);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Admin form = new Admin();
            form.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            con.Close();
            try
            {
                if (textBox2.Text == "")
                {
                    MessageBox.Show("Введите ID для обновления");
                }
                else
                {
                    con.Open();
                    SqlCommand cmdupdate = new SqlCommand("Update Ourder SET id_buyer='" + textBox3.Text + "',id_seller='" + textBox4.Text + "' ,Data_and_time='" + textBox5.Text + "' ,Sale='" + textBox6.Text + "' where ID=" + textBox2.Text + "", con);
                    cmdupdate.CommandType = CommandType.Text;
                    cmdupdate.ExecuteNonQuery();
                    MessageBox.Show("База обновлена");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox2.Text == "")
                {
                    MessageBox.Show("Введите ID для удаления");
                }
                else
                {
                    SqlCommand cmddel = new SqlCommand("Delete Ourder where ID=" + textBox2.Text + "", con);
                    con.Open();
                    cmddel.CommandType = CommandType.Text;
                    cmddel.ExecuteNonQuery();
                    MessageBox.Show("Данные удалены");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
        }

        private void Ourders_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
