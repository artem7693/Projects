﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormUI
{
    public class Delivery
    {
        public int ID { get; set; }
        public int id_seller { get; set; }
        public int id_buyer { get; set; }
        public int id_office { get; set; }
        public int id_ourder { get; set; }
        public string Track_number { get; set; }
        public DateTime Date_of_sending { get; set; }
    }
}