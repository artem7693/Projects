﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormUI
{
    public class Ourder
    {
        public int ID { get; set; }
        public int id_buyer { get; set; }
        public int id_seller { get; set; }
        public DateTime Data_and_time { get; set; }
        public int Sale { get; set; }

        public string FullInfoOurder
        {
            get
            {
                return $"{ID} {id_buyer} {id_seller} {Data_and_time} {Sale}";
            }

        }
    }
}
