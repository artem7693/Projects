﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormUI
{
    public class Good
    {
        public int ID { get; set; }
        public int id_manufacturer { get; set; }
        public int Quantity { get; set; }
        public string Price { get; set; }
        public int id_type_of_good { get; set; }
    }
}
