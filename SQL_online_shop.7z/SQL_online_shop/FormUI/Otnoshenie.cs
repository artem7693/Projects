﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.OleDb;

namespace FormUI
{
    public partial class Otnoshenie : Form
    {
        List<Buyer> Buyer = new List<Buyer>();
        List<Rewiews> Rewiews = new List<Rewiews>();
        List<Card> Card = new List<Card>();
        List<Good> Good = new List<Good>();

        SqlCommand cmd;

        public Otnoshenie()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True");
        private string connectionString;

        private void button1_Click(object sender, EventArgs e)
        {
            string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
            SqlConnection myConnection = new SqlConnection(connectString);
            myConnection.Open();
            SqlDataAdapter da = new SqlDataAdapter("Select ФИО_Покупателя, ФИО_Продавца, Отзыв, Дата_получения, Номер_карты, Трек_номер from Buyers_ID Where ФИО_Покупателя = '" + textBox1.Text + "'", myConnection);
            DataTable dt = new DataTable();           
            da.Fill(dt);
            dataGridView2.DataSource = dt;
            dataGridView2.AutoGenerateColumns = false;
            dataGridView2.RowHeadersVisible = false;
            myConnection.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
            SqlConnection myConnection = new SqlConnection(connectString);
            myConnection.Open();
            string query = "SELECT ФИО_Покупателя, ФИО_Продавца, Отзыв, Дата_получения, Номер_карты, Трек_номер FROM Buyers_ID";
            SqlCommand command = new SqlCommand(query, myConnection);
            SqlDataReader reader = command.ExecuteReader();
            List<string[]> data = new List<string[]>();
            while (reader.Read())
            {
                data.Add(new string[6]);
                data[data.Count - 1][0] = reader[0].ToString();
                data[data.Count - 1][1] = reader[1].ToString();
                data[data.Count - 1][2] = reader[2].ToString();
                data[data.Count - 1][3] = reader[3].ToString();
                data[data.Count - 1][4] = reader[4].ToString();
                data[data.Count - 1][5] = reader[5].ToString();
            }
            reader.Close();
            myConnection.Close();
            foreach (string[] s in data)
                dataGridView1.Rows.Add(s);
        }

        private void Otnoshenie_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Admin form = new Admin();
            form.ShowDialog();
        }
    }
}
