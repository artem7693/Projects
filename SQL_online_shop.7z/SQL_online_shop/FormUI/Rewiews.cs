﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormUI
{
    public class Rewiews
    {
        public int id_good { get; set; }
        public int id_buyer { get; set; }
        public int id_seller { get; set; }
        public int Rate { get; set; }
        public string Note { get; set; }
        public DateTime Date { get; set; }
    }
}
