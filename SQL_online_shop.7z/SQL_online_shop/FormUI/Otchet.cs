﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.OleDb;

namespace FormUI
{
    public partial class Otchet : Form
    {
        public Otchet()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True");

        private void button3_Click(object sender, EventArgs e)
        {
            using (var sqlConn = new SqlConnection(@"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True"))
            {
                string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
                SqlConnection myConnection = new SqlConnection(connectString);
                var sqlCmd = new SqlCommand("Country_proced", sqlConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlConn.Open();
                List<string[]> data = new List<string[]>();
                using (SqlDataReader reader = sqlCmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int intColumn = reader.GetInt32(reader.GetOrdinal("Country"));
                        data.Add(new string[1]);
                        data[data.Count - 1][0] = intColumn.ToString();
                    }
                    reader.Close();
                    myConnection.Close();
                    foreach (string[] s in data)
                        dataGridView1.Rows.Add(s);
                }
            }
        }

        private void Otchet_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (var sqlConn = new SqlConnection(@"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True"))
            {
                string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
                SqlConnection myConnection = new SqlConnection(connectString);
                var sqlCmd = new SqlCommand("Good_proc", sqlConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlConn.Open();
                List<string[]> data = new List<string[]>();
                using (SqlDataReader reader = sqlCmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int intColumn = reader.GetInt32(reader.GetOrdinal("Quantity"));
                        data.Add(new string[1]);
                        data[data.Count - 1][0] = intColumn.ToString();
                    }
                    reader.Close();
                    myConnection.Close();
                    foreach (string[] s in data)
                        dataGridView3.Rows.Add(s);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            using (var sqlConn = new SqlConnection(@"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True"))
            {
                string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
                SqlConnection myConnection = new SqlConnection(connectString);
                var sqlCmd = new SqlCommand("Summa_proc", sqlConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlConn.Open();
                List<string[]> data = new List<string[]>();
                using (SqlDataReader reader = sqlCmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int intColumn = reader.GetInt32(reader.GetOrdinal("Rate"));
                        data.Add(new string[1]);
                        data[data.Count - 1][0] = intColumn.ToString();
                    }
                    reader.Close();
                    myConnection.Close();
                    foreach (string[] s in data)
                        dataGridView4.Rows.Add(s);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (var sqlConn = new SqlConnection(@"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True"))
            {
                string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
                SqlConnection myConnection = new SqlConnection(connectString);
                var sqlCmd = new SqlCommand("Summa_procc", sqlConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlConn.Open();
                List<string[]> data = new List<string[]>();
                using (SqlDataReader reader = sqlCmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int intColumn = reader.GetInt32(reader.GetOrdinal("Rate"));
                        data.Add(new string[1]);
                        data[data.Count - 1][0] = intColumn.ToString();
                    }
                    reader.Close();
                    myConnection.Close();
                    foreach (string[] s in data)
                        dataGridView2.Rows.Add(s);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            using (var sqlConn = new SqlConnection(@"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True"))
            {
                string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
                SqlConnection myConnection = new SqlConnection(connectString);
                var sqlCmd = new SqlCommand("Summa_tovarov", sqlConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlConn.Open();
                List<string[]> data = new List<string[]>();
                using (SqlDataReader reader = sqlCmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int intColumn = reader.GetInt32(reader.GetOrdinal("Price"));
                        data.Add(new string[1]);
                        data[data.Count - 1][0] = intColumn.ToString();
                    }
                    reader.Close();
                    myConnection.Close();
                    foreach (string[] s in data)
                        dataGridView5.Rows.Add(s);
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            using (var sqlConn = new SqlConnection(@"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True"))
            {
                string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
                SqlConnection myConnection = new SqlConnection(connectString);
                var sqlCmd = new SqlCommand("Min_tovar", sqlConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlConn.Open();
                List<string[]> data = new List<string[]>();
                using (SqlDataReader reader = sqlCmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int intColumn = reader.GetInt32(reader.GetOrdinal("Price"));
                        data.Add(new string[1]);
                        data[data.Count - 1][0] = intColumn.ToString();
                    }
                    reader.Close();
                    myConnection.Close();
                    foreach (string[] s in data)
                        dataGridView6.Rows.Add(s);
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            using (var sqlConn = new SqlConnection(@"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True"))
            {
                string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
                SqlConnection myConnection = new SqlConnection(connectString);
                var sqlCmd = new SqlCommand("Max_tovar", sqlConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlConn.Open();
                List<string[]> data = new List<string[]>();
                using (SqlDataReader reader = sqlCmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int intColumn = reader.GetInt32(reader.GetOrdinal("Price"));
                        data.Add(new string[1]);
                        data[data.Count - 1][0] = intColumn.ToString();
                    }
                    reader.Close();
                    myConnection.Close();
                    foreach (string[] s in data)
                        dataGridView7.Rows.Add(s);
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            using (var sqlConn = new SqlConnection(@"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True"))
            {
                string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
                SqlConnection myConnection = new SqlConnection(connectString);
                var sqlCmd = new SqlCommand("Summa_proc3", sqlConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlConn.Open();
                List<string[]> data = new List<string[]>();
                using (SqlDataReader reader = sqlCmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int intColumn = reader.GetInt32(reader.GetOrdinal("Rate"));
                        data.Add(new string[1]);
                        data[data.Count - 1][0] = intColumn.ToString();
                    }
                    reader.Close();
                    myConnection.Close();
                    foreach (string[] s in data)
                        dataGridView8.Rows.Add(s);
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            using (var sqlConn = new SqlConnection(@"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True"))
            {
                string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
                SqlConnection myConnection = new SqlConnection(connectString);
                var sqlCmd = new SqlCommand("Summa_proc4", sqlConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlConn.Open();
                List<string[]> data = new List<string[]>();
                using (SqlDataReader reader = sqlCmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int intColumn = reader.GetInt32(reader.GetOrdinal("Rate"));
                        data.Add(new string[1]);
                        data[data.Count - 1][0] = intColumn.ToString();
                    }
                    reader.Close();
                    myConnection.Close();
                    foreach (string[] s in data)
                        dataGridView9.Rows.Add(s);
                }
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            using (var sqlConn = new SqlConnection(@"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True"))
            {
                string connectString = @"Data Source=АРТЁМ-ПК\SQLEXPRESS;Initial Catalog=Online_shop;Integrated Security=True";
                SqlConnection myConnection = new SqlConnection(connectString);
                var sqlCmd = new SqlCommand("Summa_proc5", sqlConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlConn.Open();
                List<string[]> data = new List<string[]>();
                using (SqlDataReader reader = sqlCmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int intColumn = reader.GetInt32(reader.GetOrdinal("Rate"));
                        data.Add(new string[1]);
                        data[data.Count - 1][0] = intColumn.ToString();
                    }
                    reader.Close();
                    myConnection.Close();
                    foreach (string[] s in data)
                        dataGridView10.Rows.Add(s);
                }
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            User form = new User();
            form.ShowDialog();
        }
    }
}
